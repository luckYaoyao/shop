
-- -----------------------------
-- Table structure for `eb_agent_level`
-- -----------------------------
DROP TABLE IF EXISTS `eb_agent_level`;
CREATE TABLE `eb_agent_level` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '等级名称',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '背景图',
  `one_brokerage` smallint(5) NOT NULL DEFAULT '0' COMMENT '一级分拥上浮比例',
  `two_brokerage` smallint(5) NOT NULL DEFAULT '0' COMMENT '二级分拥上浮比例',
  `grade` smallint(5) NOT NULL DEFAULT '0' COMMENT '等级',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='分销员等级表';

-- -----------------------------
-- Records of `eb_agent_level`
-- -----------------------------
INSERT INTO `eb_agent_level` VALUES ('1', '一级分销', '/statics/system_images/spread_level_1.png', '1', '1', '1', '1', '0', '1630310923');
INSERT INTO `eb_agent_level` VALUES ('2', '二级分销', '/statics/system_images/spread_level_2.png', '2', '2', '2', '1', '0', '1630311000');
INSERT INTO `eb_agent_level` VALUES ('3', '三级分销', '/statics/system_images/spread_level_3.png', '3', '3', '3', '1', '0', '1630311024');
INSERT INTO `eb_agent_level` VALUES ('4', '四级分销', '/statics/system_images/spread_level_4.png', '4', '4', '4', '1', '0', '1630311052');
INSERT INTO `eb_agent_level` VALUES ('5', '五级分销', '/statics/system_images/spread_level_5.png', '5', '5', '5', '1', '0', '1630311069');
